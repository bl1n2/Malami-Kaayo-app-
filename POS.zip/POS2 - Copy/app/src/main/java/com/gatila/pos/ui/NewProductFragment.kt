package com.gatila.pos.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.gatila.pos.R

class NewProductFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_new_product, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val nameInput = view.findViewById<EditText>(R.id.input_product_name)
        val idInput = view.findViewById<EditText>(R.id.input_product_id)
        val priceInput = view.findViewById<EditText>(R.id.input_product_price)
        val submitBtn = view.findViewById<Button>(R.id.btn_submit)

        submitBtn.setOnClickListener {
            val name = nameInput.text.toString()
            val id = idInput.text.toString()
            val price = priceInput.text.toString()
            // Add validation or data submission logic here
            Toast.makeText(requireContext(), "Submitted: $name", Toast.LENGTH_SHORT).show()
        }
    }
}
