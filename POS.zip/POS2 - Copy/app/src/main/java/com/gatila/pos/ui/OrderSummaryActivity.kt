package com.gatila.pos.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.gatila.pos.databinding.ActivityHistorySystemBinding

class OrderSummaryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistorySystemBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistorySystemBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val order = intent.getSerializableExtra("order_data") as? Order

        if (order != null) {
            binding.dateText.text = order.date
            binding.timeText.text = order.time
            binding.codeText.text = order.codeNumber
            binding.itemsText.text = order.itemsPurchased
            binding.orderNoText.text = order.orderNumber
        }
    }
}
