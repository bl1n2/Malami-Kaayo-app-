package com.gatila.pos.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.gatila.pos.R

class OrderAdapter(
    private var orders: List<Order>,
    private val onClick: (Order) -> Unit
) : RecyclerView.Adapter<OrderAdapter.OrderViewHolder>() {

    inner class OrderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val date: TextView = view.findViewById(R.id.dateText)
        val time: TextView = view.findViewById(R.id.timeText)
        val code: TextView = view.findViewById(R.id.codeText)
        val items: TextView = view.findViewById(R.id.itemsText)
        val orderNo: TextView = view.findViewById(R.id.orderNoText)

        fun bind(order: Order) {
            date.text = order.date
            time.text = order.time
            code.text = order.codeNumber
            items.text = order.itemsPurchased
            orderNo.text = order.orderNumber

            itemView.setOnClickListener { onClick(order) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.order_row, parent, false)
        return OrderViewHolder(view)
    }

    override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {
        holder.bind(orders[position])
    }

    override fun getItemCount() = orders.size

    fun updateList(newList: List<Order>) {
        orders = newList
        notifyDataSetChanged()
    }
}
