package com.gatila.pos.ui

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gatila.pos.R

class Ordering : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var productAdapter: ProductAdapter
    private lateinit var productList: ArrayList<Product>  // Your data model
    // Mock cart: simulate selected products and quantities
    private val cartItems = listOf(
        CartItem("P1", 30.0, 2),   // 2 items at ₱30
        CartItem("P2", 50.0, 1),   // 1 item at ₱50
        CartItem("P3", 25.0, 3)    // 3 items at ₱25
    )

    private fun calculateCartTotal(): Double {
        return cartItems.sumOf { it.price * it.quantity }
    }




    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ordering_system)
        setupKeypad()

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.productRecyclerView)
        recyclerView.layoutManager = GridLayoutManager(this, 2) // 2 columns

        // Initialize product list
        productList = ArrayList()
        loadProducts()

        // Set up adapter
        productAdapter = ProductAdapter(productList)
        recyclerView.adapter = productAdapter
        productAdapter.onCartUpdated = {
            updateTotal()
        }
    }
    private lateinit var cashInput: EditText
    private var inputBuilder = StringBuilder()

    private fun setupKeypad() {
        cashInput = findViewById(R.id.cashInput)

        val buttons = mapOf(
            R.id.btn0 to "0", R.id.btn1 to "1", R.id.btn2 to "2",
            R.id.btn3 to "3", R.id.btn4 to "4", R.id.btn5 to "5",
            R.id.btn6 to "6", R.id.btn7 to "7", R.id.btn8 to "8",
            R.id.btn9 to "9", R.id.btnDot to "."
        )

        for ((id, value) in buttons) {
            findViewById<Button>(id).setOnClickListener {
                inputBuilder.append(value)
                cashInput.setText(inputBuilder.toString())
            }
        }

        findViewById<Button>(R.id.btnClear).setOnClickListener {
            inputBuilder.clear()
            cashInput.setText("")
        }

        findViewById<Button>(R.id.btnEnter).setOnClickListener {
            val cash = inputBuilder.toString().toDoubleOrNull() ?: 0.0
            val total = calculateCartTotal()
            val change = cash - total
            findViewById<TextView>(R.id.changeLabel).text = "Change: ₱${"%.2f".format(change)}"
        }
    }
    private fun updateTotal() {
        val total = productList.sumOf { it.price * it.quantity }
        findViewById<TextView>(R.id.changeLabel).text = "Total: ₱${"%.2f".format(total)}"
    }



    private fun loadProducts() {
        // Example items, you can load more
        productList.add(Product(R.drawable.mona2, "P1", 30.00))
        productList.add(Product(R.drawable.mona2, "P2", 30.00))
        productList.add(Product(R.drawable.mona2, "P3", 30.00))
        productList.add(Product(R.drawable.mona2, "P4", 30.00))
        productList.add(Product(R.drawable.mona2, "P5", 30.00))
        productList.add(Product(R.drawable.mona2, "P6", 30.00))
        // etc.
    }
}
