package com.gatila.pos.ui

data class Product(
    val imageResId: Int,
    val name: String,
    val price: Double,
    var quantity: Int = 0  // ✅ This line is essential!
)
