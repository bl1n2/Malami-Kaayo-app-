package com.gatila.pos.ui

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gatila.pos.R

class InventoryActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var productList: MutableList<String>
    private lateinit var adapter: ArrayAdapter<String>

    private val addProductLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val data = result.data
            val name = data?.getStringExtra("productName")
            val id = data?.getStringExtra("productId")
            val price = data?.getStringExtra("productPrice")

            if (name != null && id != null && price != null) {
                val productDisplay = "Name: $name | ID: $id | Price: ₱$price"
                productList.add(productDisplay)
                adapter.notifyDataSetChanged()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product_management)

        val addButton = findViewById<Button>(R.id.btn_add)
        recyclerView = findViewById(R.id.recycler_view)

        productList = mutableListOf()
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, productList)

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter =
            ProductAdapter(productList) // custom adapter mo ito (gawa natin later if needed)

        addButton.setOnClickListener {
            val intent = Intent(this, FloatAdd::class.java)
            addProductLauncher.launch(intent)
        }
    }
}