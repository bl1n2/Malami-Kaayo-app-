package com.gatila.pos.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.gatila.pos.ui.InventoryActivity
import com.gatila.pos.databinding.ActivityDashboardBinding
import java.util.Calendar

class DashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDashboardBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupClickListeners()
        greetUser()
    }

    private fun setupClickListeners() {
        binding.btnHistory.setOnClickListener {
            showFeatureComingSoon("History")
        }

        binding.btnInventory.setOnClickListener {
            val intent = Intent(this, InventoryActivity::class.java)
            startActivity(intent)
        }

        binding.btnPos.setOnClickListener {
            showFeatureComingSoon("Point of Sale")
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun greetUser() {
        val greeting = when (val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
            in 0..11 -> "Good Morning"
            in 12..17 -> "Good Afternoon"
            else -> "Good Evening"
        }
        Toast.makeText(this, "$greeting! Welcome to the Dashboard.", Toast.LENGTH_LONG).show()
    }

    private fun showFeatureComingSoon(feature: String) {
        AlertDialog.Builder(this)
            .setTitle("Coming Soon")
            .setMessage("The $feature feature is coming soon. Stay tuned!")
            .setPositiveButton("OK", null)
            .show()
    }
}
