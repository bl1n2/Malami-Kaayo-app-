package com.gatila.pos.ui

data class CartItem(
    val name: String,
    val price: Double,
    val quantity: Int
)
