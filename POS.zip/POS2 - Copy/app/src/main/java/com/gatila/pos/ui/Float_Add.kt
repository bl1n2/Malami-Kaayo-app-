package com.gatila.pos.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.gatila.pos.ui.InventoryActivity
import com.gatila.pos.R

class FloatAdd : AppCompatActivity() {

    private lateinit var editTextProductName: EditText
    private lateinit var editTextProductId: EditText
    private lateinit var editTextProductPrice: EditText
    private lateinit var submitButton: Button
    private lateinit var imagePreview: ImageView
    private lateinit var selectImageButton: ImageButton
    private lateinit var backButton: ImageView

    private var imageUri: Uri? = null

    // Example existing IDs (in real app, retrieve from DB or intent)
    private val existingIds = listOf("101", "102")

    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        imageUri = uri
        imageUri?.let { imagePreview.setImageURI(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dialog_add_product)

        initializeViews()

        submitButton.setOnClickListener { handleSubmitButtonClick() }
        selectImageButton.setOnClickListener { pickImageLauncher.launch("image/*") }
        backButton.setOnClickListener { navigateToInventoryActivity() }

        addValidationListener()
    }

    private fun initializeViews() {
        editTextProductName = findViewById(R.id.editTextText)
        editTextProductId = findViewById(R.id.editTextText2)
        editTextProductPrice = findViewById(R.id.editTextText3)
        submitButton = findViewById(R.id.submitButton)
        selectImageButton = findViewById(R.id.imageButton)
        backButton = findViewById(R.id.imageView25)
        imagePreview = findViewById(R.id.imagePreview)
    }

    private fun addValidationListener() {
        val watcher = object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                submitButton.isEnabled = listOf(
                    editTextProductName.text,
                    editTextProductId.text,
                    editTextProductPrice.text
                ).all { it.isNotBlank() }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        }

        editTextProductName.addTextChangedListener(watcher)
        editTextProductId.addTextChangedListener(watcher)
        editTextProductPrice.addTextChangedListener(watcher)
    }

    private fun handleSubmitButtonClick() {
        val productName = editTextProductName.text.toString().trim().replaceFirstChar { it.uppercase() }
        val productId = editTextProductId.text.toString().trim()
        val productPrice = editTextProductPrice.text.toString().trim()

        when {
            productName.isEmpty() || productId.isEmpty() || productPrice.isEmpty() -> showToast("Please fill in all fields.")
            !productId.matches(Regex("^[0-9]+$")) -> showToast("Product ID must be numeric.")
            existingIds.contains(productId) -> showToast("Product ID already exists.")
            !isValidPrice(productPrice) -> showToast("Invalid price format. Use 0.00")
            else -> {
                val formattedPrice = String.format("%.2f", productPrice.toDouble())
                showConfirmationDialog(productName, productId, formattedPrice)
            }
        }
    }

    private fun isValidPrice(price: String): Boolean {
        return price.matches(Regex("^[0-9]+(\\.[0-9]{1,2})?$"))
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun showConfirmationDialog(name: String, id: String, price: String) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_confirmation, null)
        val message = dialogView.findViewById<TextView>(R.id.dialogMessage1)
        message.text = "You are about to save this product:\n\nName: $name\nID: $id\nPrice: $price\n\nAre you sure?"

        val alertDialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)
            .create()

        dialogView.findViewById<Button>(R.id.continueButton2).setOnClickListener {
            saveProductData(name, id, price)
            alertDialog.dismiss()
        }

        dialogView.findViewById<Button>(R.id.cancelButton3).setOnClickListener {
            alertDialog.dismiss()
        }

        alertDialog.show()
    }

    private fun saveProductData(name: String, id: String, price: String) {
        val resultIntent = Intent().apply {
            putExtra("productName", name)
            putExtra("productId", id)
            putExtra("productPrice", price)
            imageUri?.let { putExtra("productImageUri", it.toString()) }
        }
        setResult(RESULT_OK, resultIntent)
        finish()
    }

    private fun navigateToInventoryActivity() {
        startActivity(Intent(this, InventoryActivity::class.java))
        finish()
    }
}
