package com.gatila.pos.ui

import java.io.Serializable

data class Order(
    val date: String,
    val time: String,
    val codeNumber: String,
    val itemsPurchased: String,
    val orderNumber: String
) : Serializable
