package com.gatila.pos.ui

data class OrderedItem(
    val name: String,
    val quantity: Int,
    val price: Double
)

