package com.gatila.pos.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.gatila.pos.R

class OrderedProductAdapter(private val items: List<OrderedItem>) :
    RecyclerView.Adapter<OrderedProductAdapter.OrderedProductViewHolder>() {

    class OrderedProductViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nameText: TextView = itemView.findViewById(R.id.item_name_qty)
        val priceText: TextView = itemView.findViewById(R.id.item_subtotal)
        // etc.
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderedProductViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.ordered_item, parent, false)
        return OrderedProductViewHolder(view)
    }


    override fun onBindViewHolder(holder: OrderedProductViewHolder, position: Int) {
        val product = items[position]
        holder.nameText.text = product.name
        holder.priceText.text = "${product.quantity} × ₱${product.price}"
    }

    override fun getItemCount(): Int = items.size
}
