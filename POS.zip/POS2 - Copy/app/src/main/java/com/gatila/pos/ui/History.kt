package com.gatila.pos.ui

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.EditText
import com.gatila.pos.databinding.ActivityHistorySystemBinding

class OrderHistory : AppCompatActivity() {

    private lateinit var binding: ActivityHistorySystemBinding
    private lateinit var adapter: OrderAdapter
    private lateinit var allOrders: List<Order>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistorySystemBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Sample list of orders (in real app, load from DB or intent)
        allOrders = listOf(
            Order("2025-05-01", "10:30", "CN001", "Burger, Fries", "ORD1001"),
            Order("2025-05-02", "11:45", "CN002", "Pizza", "ORD1002"),
            Order("2025-05-03", "12:15", "CN003", "Hotdog, Soda", "ORD1003")
        )

        // Set up RecyclerView
        adapter = OrderAdapter(allOrders) { selectedOrder ->
            val intent = Intent(this, OrderSummaryActivity::class.java)
            intent.putExtra("order_data", selectedOrder)
            startActivity(intent)
        }

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        // Search functionality
        binding.searchRow.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val query = s.toString().lowercase()
                val filtered = allOrders.filter {
                    it.date.contains(query, true) ||
                            it.time.contains(query, true) ||
                            it.codeNumber.contains(query, true) ||
                            it.itemsPurchased.contains(query, true) ||
                            it.orderNumber.contains(query, true)
                }
                adapter.updateList(filtered)
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }
}
